# Python Conditional Statements – Assignments (No Loops)

This folder contains my solutions to the 50 conditional-statement assignment questions. Each question is saved in its own Python file.

## How to run

Run a file from a terminal, for example:

```bash
python 01_positive_negative.py
```

Questions 41–50 use `match-case`, which requires Python 3.10 or newer.

## Corrections made

The files are based on the code I supplied. A few clear mistakes were corrected while keeping the same coding style and outputs where possible:

- Q7 checks that the input is one alphabet character before checking vowels.
- Q10 and Q30 handle negative numbers when checking digit count.
- Q11 follows the assignment condition of temperature greater than 30.
- Q16 and Q21 handle ties correctly when finding greatest/smallest values.
- Q23 calculates electricity charges by unit slabs, using the rates from my code (5, 7, and 10).
- Q25 checks that the side lengths can form a valid triangle.
- Q38 prints a more accurate failure message.
- Q43 checks leap years when calculating February's days.

For questions where the assignment does not give exact rules, the thresholds and rates remain based on the code I supplied. Please review them against your teacher's instructions.
